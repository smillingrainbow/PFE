var structcimg__library__suffixed_1_1_c_img_instance_exception =
[
    [ "CImgInstanceException", "structcimg__library__suffixed_1_1_c_img_instance_exception.html#a2fdde8bb00abef3ce8522891813a9669", null ]
];