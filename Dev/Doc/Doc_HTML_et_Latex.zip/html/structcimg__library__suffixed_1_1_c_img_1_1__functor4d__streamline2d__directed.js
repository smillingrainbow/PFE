var structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline2d__directed =
[
    [ "_functor4d_streamline2d_directed", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline2d__directed.html#a1f75ad71877ddbcd7ae34cac3ed1145c", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline2d__directed.html#a79c2195b45c4e1bcd06d31d60db1b3e3", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline2d__directed.html#a83088592588a54fe8db896605d614fe0", null ]
];