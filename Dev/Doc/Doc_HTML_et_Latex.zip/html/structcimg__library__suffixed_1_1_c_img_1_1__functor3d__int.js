var structcimg__library__suffixed_1_1_c_img_1_1__functor3d__int =
[
    [ "_functor3d_int", "structcimg__library__suffixed_1_1_c_img_1_1__functor3d__int.html#aa92ae8b290434512ecee05188c3d34cc", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor3d__int.html#a6224abd5300b97c790aa6ae10f17eedd", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor3d__int.html#a9706d22ee054bd7e0434e847989f6726", null ]
];