var structcimg__library__suffixed_1_1_c_img_1_1__functor2d__float =
[
    [ "_functor2d_float", "structcimg__library__suffixed_1_1_c_img_1_1__functor2d__float.html#a3f5fbc638004f436de102e91e7c7815f", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor2d__float.html#aed030fecb45b43ec997ef9996e40a308", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor2d__float.html#a6ea8592ea6d6bdc7b0e95d3f72a4aa20", null ]
];