var structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__oriented =
[
    [ "_functor4d_streamline3d_oriented", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__oriented.html#a802e4860ae942bde89b9a276aa09d7dc", null ],
    [ "~_functor4d_streamline3d_oriented", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__oriented.html#ac6d6807bfefa6e1a7b08f31d9d0fc3f1", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__oriented.html#a27e24f470d7acd9e395715396e556201", null ],
    [ "pI", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__oriented.html#ab0942d28e7db2c3130a6051abeb2d6f4", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__oriented.html#a9d776659c2fdbddec7a8e980a37c0605", null ]
];