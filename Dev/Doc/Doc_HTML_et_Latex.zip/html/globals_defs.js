var globals_defs =
[
    [ "_", "globals_defs.html", null ],
    [ "c", "globals_defs_c.html", null ]
];