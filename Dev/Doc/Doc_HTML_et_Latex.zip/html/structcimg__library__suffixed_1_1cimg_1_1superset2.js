var structcimg__library__suffixed_1_1cimg_1_1superset2 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset2.html#a4f850744d5b934265ec7f77920404b89", null ]
];