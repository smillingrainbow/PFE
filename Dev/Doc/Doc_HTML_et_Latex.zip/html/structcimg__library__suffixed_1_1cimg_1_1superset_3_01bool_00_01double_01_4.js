var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01double_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01double_01_4.html#a421bed2237f8065dfc21034a205eb345", null ]
];