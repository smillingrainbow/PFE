var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01int_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01int_01_4.html#a58e3cd58cfe47ea7ed381d7aeebab81b", null ]
];