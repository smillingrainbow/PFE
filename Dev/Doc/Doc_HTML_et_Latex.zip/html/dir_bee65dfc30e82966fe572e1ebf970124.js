var dir_bee65dfc30e82966fe572e1ebf970124 =
[
    [ "controller.cpp", "controller_8cpp.html", null ],
    [ "controller.h", "controller_8h.html", [
      [ "Controller", "class_controller.html", "class_controller" ]
    ] ],
    [ "controllerthread.cpp", "controllerthread_8cpp.html", null ],
    [ "controllerthread.h", "controllerthread_8h.html", [
      [ "ControllerThread", "class_controller_thread.html", "class_controller_thread" ]
    ] ],
    [ "filterbilateral.cpp", "filterbilateral_8cpp.html", null ],
    [ "filterbilateral.h", "filterbilateral_8h.html", "filterbilateral_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "widgetImage.cpp", "widget_image_8cpp.html", null ],
    [ "widgetImage.h", "widget_image_8h.html", [
      [ "WidgetImage", "class_widget_image.html", "class_widget_image" ]
    ] ]
];