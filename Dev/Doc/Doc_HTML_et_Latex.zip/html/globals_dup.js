var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "m", "globals_m.html", null ]
];