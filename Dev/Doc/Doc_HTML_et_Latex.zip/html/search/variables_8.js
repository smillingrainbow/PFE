var searchData=
[
  ['mainwidjet',['mainWidjet',['../class_main_window.html#a94fce9f5b7a2dd7564bb91b3e624f7c0',1,'MainWindow']]]
];
