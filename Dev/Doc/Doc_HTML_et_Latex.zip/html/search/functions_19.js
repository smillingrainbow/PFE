var searchData=
[
  ['ycbcrtorgb',['YCbCrtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#a00f803407df18a117adca1f75abd9aed',1,'cimg_library_suffixed::CImg']]],
  ['yuvtorgb',['YUVtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#ab482b000aa2416bf063cfb4709b27e28',1,'cimg_library_suffixed::CImg']]]
];
