var searchData=
[
  ['detail',['detail',['../class_controller.html#a127bee2ea360971f91d09afaf938de79',1,'Controller']]],
  ['detailsgroupbox',['detailsGroupBox',['../class_widget_image.html#a4d19ec91a55cb749cb098cec20a01e26',1,'WidgetImage']]]
];
