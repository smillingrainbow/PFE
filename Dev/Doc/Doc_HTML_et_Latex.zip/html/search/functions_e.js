var searchData=
[
  ['nan',['nan',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01double_01_4.html#ae3c33f103b0328e4455c88a36bdccdcc',1,'cimg_library_suffixed::cimg::type&lt; double &gt;::nan()'],['../structcimg__library__suffixed_1_1cimg_1_1type_3_01float_01_4.html#ac5696859985362db837b405b9ad878db',1,'cimg_library_suffixed::cimg::type&lt; float &gt;::nan()']]],
  ['navloadbuttonclicked',['navLoadButtonClicked',['../class_widget_image.html#a729cb696f8d047078ed90092bd51ba83',1,'WidgetImage']]],
  ['navsavebuttonclicked',['navSaveButtonClicked',['../class_widget_image.html#a78eb859d20dfc74f75674aae6adecd07',1,'WidgetImage']]],
  ['nb_5fcpus',['nb_cpus',['../namespacecimg__library__suffixed_1_1cimg.html#ad359a27ccc2eea27d3a6f1073b2a2ad7',1,'cimg_library_suffixed::cimg']]],
  ['nearest_5fpow2',['nearest_pow2',['../namespacecimg__library__suffixed_1_1cimg.html#a3b4f5d0bf0af9638962204b8c3919774',1,'cimg_library_suffixed::cimg']]],
  ['noise',['noise',['../structcimg__library__suffixed_1_1_c_img.html#a6049c651eefc3a13b8f7d1fc3ff225d7',1,'cimg_library_suffixed::CImg']]],
  ['norm',['norm',['../structcimg__library__suffixed_1_1_c_img.html#ab850013f0ed453ba91ac0004e76f5d78',1,'cimg_library_suffixed::CImg']]],
  ['normalization',['normalization',['../structcimg__library__suffixed_1_1_c_img_display.html#af2d480e47d9b0dc52d373b54fa01f805',1,'cimg_library_suffixed::CImgDisplay']]],
  ['normalize',['normalize',['../structcimg__library__suffixed_1_1_c_img.html#ae09b1b5a07556aab26db766c661f2b44',1,'cimg_library_suffixed::CImg::normalize(const T min_value, const T max_value)'],['../structcimg__library__suffixed_1_1_c_img.html#acf91acd5fba09e7ecc3bb708b0a0b8dd',1,'cimg_library_suffixed::CImg::normalize()']]],
  ['number_5ffilename',['number_filename',['../namespacecimg__library__suffixed_1_1cimg.html#ab58f430d4a05a010742c012efd4a7000',1,'cimg_library_suffixed::cimg']]]
];
