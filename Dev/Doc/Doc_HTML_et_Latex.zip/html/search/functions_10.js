var searchData=
[
  ['paint',['paint',['../structcimg__library__suffixed_1_1_c_img_display.html#aff557cf3b60169ddfd4336b37c653fe0',1,'cimg_library_suffixed::CImgDisplay']]],
  ['permute_5faxes',['permute_axes',['../structcimg__library__suffixed_1_1_c_img.html#a246ec3c9585a6afb847c938e45f4cdc8',1,'cimg_library_suffixed::CImg']]],
  ['pixel_5ftype',['pixel_type',['../structcimg__library__suffixed_1_1_c_img.html#ab5cb3e6f07f2cd894641aa6a26807c1e',1,'cimg_library_suffixed::CImg::pixel_type()'],['../structcimg__library__suffixed_1_1_c_img_list.html#a55a11e1b7827dac9e38f29e1c4cfb3ec',1,'cimg_library_suffixed::CImgList::pixel_type()']]],
  ['plane3d',['plane3d',['../structcimg__library__suffixed_1_1_c_img.html#a38bca8940aa19a72153372c6615a0c61',1,'cimg_library_suffixed::CImg']]],
  ['pop_5fback',['pop_back',['../structcimg__library__suffixed_1_1_c_img_list.html#ac619bd8222ff38259b6f891ae3f646bb',1,'cimg_library_suffixed::CImgList']]],
  ['pop_5ffront',['pop_front',['../structcimg__library__suffixed_1_1_c_img_list.html#afb5883af31042787f25c35c9d044de6e',1,'cimg_library_suffixed::CImgList']]],
  ['pow',['pow',['../structcimg__library__suffixed_1_1_c_img.html#a56a46a3c08972775c5c2451f178be1a6',1,'cimg_library_suffixed::CImg::pow(const double p)'],['../structcimg__library__suffixed_1_1_c_img.html#a949bdad0b186d9ab93f06a5b3da976c0',1,'cimg_library_suffixed::CImg::pow(const char *const expression)'],['../structcimg__library__suffixed_1_1_c_img.html#a47d139a477afd4815a56988dc0cd547e',1,'cimg_library_suffixed::CImg::pow(const CImg&lt; t &gt; &amp;img)']]],
  ['prand',['prand',['../namespacecimg__library__suffixed_1_1cimg.html#a2a18bbfb6a496d8d5a02943be8eaa936',1,'cimg_library_suffixed::cimg']]],
  ['print',['print',['../structcimg__library__suffixed_1_1_c_img.html#aeeb5efc38fc06c0fb29019af9b5cd44e',1,'cimg_library_suffixed::CImg::print()'],['../structcimg__library__suffixed_1_1_c_img_list.html#ad03b31f8d8e1f04c6f95949ba5c5f3e0',1,'cimg_library_suffixed::CImgList::print()']]],
  ['projections2d',['projections2d',['../structcimg__library__suffixed_1_1_c_img.html#a4cccccba4bf9ef2f7c087fd61083c9b6',1,'cimg_library_suffixed::CImg']]],
  ['pseudoinvert',['pseudoinvert',['../structcimg__library__suffixed_1_1_c_img.html#a58fcdf39d42f60a49ee5990669469a39',1,'cimg_library_suffixed::CImg::pseudoinvert()'],['../namespacecimg__library__suffixed.html#aa2cd51ec8b416d2ca4299253e618d343',1,'cimg_library_suffixed::pseudoinvert()']]],
  ['psnr',['PSNR',['../structcimg__library__suffixed_1_1_c_img.html#aac11acc89a0b7152c221f46ecf2d97b1',1,'cimg_library_suffixed::CImg']]],
  ['push_5fback',['push_back',['../structcimg__library__suffixed_1_1_c_img_list.html#ac84a1c643e314bf2aeb8267a44e9970d',1,'cimg_library_suffixed::CImgList::push_back(const CImg&lt; t &gt; &amp;img)'],['../structcimg__library__suffixed_1_1_c_img_list.html#a1ea56fb5e0860f360b3ccfce50ae71e0',1,'cimg_library_suffixed::CImgList::push_back(const CImgList&lt; t &gt; &amp;list)']]],
  ['push_5ffront',['push_front',['../structcimg__library__suffixed_1_1_c_img_list.html#a7a8dcb1a1f3d1e6a8ef8537c63415933',1,'cimg_library_suffixed::CImgList::push_front(const CImg&lt; t &gt; &amp;img)'],['../structcimg__library__suffixed_1_1_c_img_list.html#a6091c1fd9d03ada9ec3ba8ed92f5bcd2',1,'cimg_library_suffixed::CImgList::push_front(const CImgList&lt; t &gt; &amp;list)']]]
];
