var searchData=
[
  ['widgetimage',['WidgetImage',['../class_widget_image.html#a4b063abf5318d6c174cb9f9b9841de9a',1,'WidgetImage']]]
];
