var searchData=
[
  ['widgetimage',['WidgetImage',['../class_widget_image.html',1,'']]]
];
