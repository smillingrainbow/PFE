var searchData=
[
  ['value_5ftype',['value_type',['../structcimg__library__suffixed_1_1_c_img.html#a9a18781e1d4ca73670e52bc4a56ec3d2',1,'cimg_library_suffixed::CImg::value_type()'],['../structcimg__library__suffixed_1_1_c_img_list.html#a41c952483793b049e58c27e11d0dd955',1,'cimg_library_suffixed::CImgList::value_type()']]]
];
