var searchData=
[
  ['longt',['longT',['../structcimg__library__suffixed_1_1_c_img.html#a32fc03aa9b0d1281bfefea670e413720',1,'cimg_library_suffixed::CImg::longT()'],['../structcimg__library__suffixed_1_1_c_img_list.html#a335386aab1cecc12ade576d77d3a4c7d',1,'cimg_library_suffixed::CImgList::longT()']]]
];
