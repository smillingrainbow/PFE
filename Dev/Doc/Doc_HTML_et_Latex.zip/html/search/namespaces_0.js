var searchData=
[
  ['cimg',['cimg',['../namespacecimg__library__suffixed_1_1cimg.html',1,'cimg_library_suffixed']]],
  ['cimg_5flibrary_5fsuffixed',['cimg_library_suffixed',['../namespacecimg__library__suffixed.html',1,'']]]
];
