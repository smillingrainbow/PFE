var searchData=
[
  ['doublet',['doubleT',['../structcimg__library__suffixed_1_1_c_img.html#aa29e255f9578a69500205c5064113006',1,'cimg_library_suffixed::CImg::doubleT()'],['../structcimg__library__suffixed_1_1_c_img_list.html#a307bd3b95847502b40d0aca77ec5783f',1,'cimg_library_suffixed::CImgList::doubleT()']]]
];
