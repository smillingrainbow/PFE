var searchData=
[
  ['savegroupbox',['saveGroupBox',['../class_widget_image.html#ad6e0964f209cc5ca1660835a8445b37a',1,'WidgetImage']]],
  ['savelineedit',['saveLineEdit',['../class_widget_image.html#ac3fbc755f8a37e815be9e762d7b229b8',1,'WidgetImage']]],
  ['sigmar',['sigmaR',['../class_controller.html#a63b6080284ba12609baf84470b683167',1,'Controller']]],
  ['sigmarlineedit',['sigmaRLineEdit',['../class_widget_image.html#a6a278f681c910c5f33a579990d0d2589',1,'WidgetImage']]],
  ['sigmas',['sigmaS',['../class_controller.html#aec9c4a0af44ee9fa3f801dfc6ca88a5e',1,'Controller']]],
  ['sigmaslineedit',['sigmaSLineEdit',['../class_widget_image.html#ac206c2d0b170a6168083b696399f488d',1,'WidgetImage']]]
];
