var searchData=
[
  ['boolt',['boolT',['../structcimg__library__suffixed_1_1_c_img.html#af9f813311fc2eecb3ccc7195625dd34f',1,'cimg_library_suffixed::CImg::boolT()'],['../structcimg__library__suffixed_1_1_c_img_list.html#a7093deeaa6a2ae97a4cad25d2390f758',1,'cimg_library_suffixed::CImgList::boolT()']]]
];
