var searchData=
[
  ['quantize',['quantize',['../structcimg__library__suffixed_1_1_c_img.html#aff02f2819c9ff20253734315f5e25022',1,'cimg_library_suffixed::CImg']]]
];
