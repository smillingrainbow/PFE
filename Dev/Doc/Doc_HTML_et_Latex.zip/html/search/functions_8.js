var searchData=
[
  ['navloadbuttonclicked',['navLoadButtonClicked',['../class_widget_image.html#a729cb696f8d047078ed90092bd51ba83',1,'WidgetImage']]],
  ['navsavebuttonclicked',['navSaveButtonClicked',['../class_widget_image.html#a78eb859d20dfc74f75674aae6adecd07',1,'WidgetImage']]]
];
