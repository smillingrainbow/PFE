var searchData=
[
  ['floatt',['floatT',['../structcimg__library__suffixed_1_1_c_img.html#a50cb2b2946ce858006d9a5ca0ca7a1c6',1,'cimg_library_suffixed::CImg::floatT()'],['../structcimg__library__suffixed_1_1_c_img_list.html#ad45ff176cc23643fb0fcf3f4ab00e9cc',1,'cimg_library_suffixed::CImgList::floatT()']]]
];
