var searchData=
[
  ['navloadbutton',['navLoadButton',['../class_widget_image.html#a19cfbf707a156e63458aecbf2ec48692',1,'WidgetImage']]],
  ['navsavebutton',['navSaveButton',['../class_widget_image.html#ac837465446128e4554a64181ac3652ff',1,'WidgetImage']]],
  ['nbiteration',['nbIteration',['../class_controller.html#a3cf245e752e346731acab1d9bb0e55bb',1,'Controller']]],
  ['nbiterationlineedit',['nbIterationLineEdit',['../class_widget_image.html#a5b7203c95d0fbb30d35a319c3c3bbd84',1,'WidgetImage']]]
];
