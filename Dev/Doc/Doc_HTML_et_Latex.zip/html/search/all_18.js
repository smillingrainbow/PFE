var searchData=
[
  ['xln',['xln',['../namespacecimg__library__suffixed_1_1cimg.html#a33280187782b500494b92832fc13e339',1,'cimg_library_suffixed::cimg']]],
  ['xyytorgb',['xyYtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#aab8245f1b6f6fab621743c9f037bd259',1,'cimg_library_suffixed::CImg']]],
  ['xyytoxyz',['xyYtoXYZ',['../structcimg__library__suffixed_1_1_c_img.html#a051b8b41d46276207243d171a44acb52',1,'cimg_library_suffixed::CImg']]],
  ['xyztolab',['XYZtoLab',['../structcimg__library__suffixed_1_1_c_img.html#acf6851bd82b7cae11aad8285528c0cc7',1,'cimg_library_suffixed::CImg']]],
  ['xyztorgb',['XYZtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#ac485b6a6a34377c3e6519654c027db79',1,'cimg_library_suffixed::CImg']]],
  ['xyztoxyy',['XYZtoxyY',['../structcimg__library__suffixed_1_1_c_img.html#a02b07a06bfbca6ca84b97f052d9e2bfc',1,'cimg_library_suffixed::CImg']]]
];
