var searchData=
[
  ['type',['type',['../structcimg__library__suffixed_1_1cimg_1_1type.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20bool_20_3e',['type&lt; bool &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01bool_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20char_20_3e',['type&lt; char &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01char_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20double_20_3e',['type&lt; double &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01double_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20float_20_3e',['type&lt; float &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01float_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20int_20_3e',['type&lt; int &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01int_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20long_20_3e',['type&lt; long &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01long_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20short_20_3e',['type&lt; short &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01short_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20signed_20char_20_3e',['type&lt; signed char &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01signed_01char_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20unsigned_20char_20_3e',['type&lt; unsigned char &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01unsigned_01char_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20unsigned_20int_20_3e',['type&lt; unsigned int &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01unsigned_01int_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20unsigned_20long_20_3e',['type&lt; unsigned long &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01unsigned_01long_01_4.html',1,'cimg_library_suffixed::cimg']]],
  ['type_3c_20unsigned_20short_20_3e',['type&lt; unsigned short &gt;',['../structcimg__library__suffixed_1_1cimg_1_1type_3_01unsigned_01short_01_4.html',1,'cimg_library_suffixed::cimg']]]
];
