var searchData=
[
  ['shortt',['shortT',['../structcimg__library__suffixed_1_1_c_img.html#ab2ba5a4200fad613c5c2634fa1ad05ba',1,'cimg_library_suffixed::CImg::shortT()'],['../structcimg__library__suffixed_1_1_c_img_list.html#ac6ec88195533b60a3e4f83514a8dfceb',1,'cimg_library_suffixed::CImgList::shortT()']]]
];
