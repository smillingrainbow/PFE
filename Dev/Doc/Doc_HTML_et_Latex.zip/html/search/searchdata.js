var indexSectionsWithContent =
{
  0: "_abcdfghilmnorsw~",
  1: "cfmw",
  2: "cfmw",
  3: "abcdfglmnrsw~",
  4: "abcdfhilmnorsw",
  5: "_"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Macros"
};

