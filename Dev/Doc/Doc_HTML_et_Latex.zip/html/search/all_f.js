var searchData=
[
  ['widgetimage',['WidgetImage',['../class_widget_image.html',1,'WidgetImage'],['../class_widget_image.html#a4b063abf5318d6c174cb9f9b9841de9a',1,'WidgetImage::WidgetImage()']]],
  ['widgetimage_2ecpp',['widgetImage.cpp',['../widget_image_8cpp.html',1,'']]],
  ['widgetimage_2eh',['widgetImage.h',['../widget_image_8h.html',1,'']]],
  ['width',['width',['../class_filter_bilateral.html#aaa3c4e4b3d7bee8fce134f6f36e66f34',1,'FilterBilateral']]]
];
