var searchData=
[
  ['set_5ffsigmar',['set_fSigmaR',['../class_filter_bilateral.html#acbf9003d2c2a5d3efbe60b6390e083e2',1,'FilterBilateral']]],
  ['set_5ffsigmas',['set_fSigmaS',['../class_filter_bilateral.html#a3d21dad3603145a73d0b2c08cd1077cd',1,'FilterBilateral']]],
  ['set_5fimg',['set_img',['../class_filter_bilateral.html#aea091395f13f7e1a51f35cbcaac2c592',1,'FilterBilateral']]],
  ['setalpha',['setAlpha',['../class_controller.html#ac4b618dd1d6d596dd67bb9e56cb5d469',1,'Controller']]],
  ['setbeta',['setBeta',['../class_controller.html#a1790b566d0ddbc8dd2260f29b741d465',1,'Controller']]],
  ['setdetail',['setDetail',['../class_controller.html#a9267e9a6eb1ce611daed255a6ef325d7',1,'Controller']]],
  ['setfilenameinput',['setFileNameInput',['../class_controller.html#aa1005130eb83a091eb72a0fed46c661e',1,'Controller']]],
  ['setnbiteration',['setNbIteration',['../class_controller.html#a410a3b034854101705725798ae9aae03',1,'Controller']]],
  ['setsigmar',['setSigmaR',['../class_controller.html#a78110a408c3c2fa0fef289d273351375',1,'Controller']]],
  ['setsigmas',['setSigmaS',['../class_controller.html#a42aeb52b0366292b895c15aa2de38ff0',1,'Controller']]]
];
