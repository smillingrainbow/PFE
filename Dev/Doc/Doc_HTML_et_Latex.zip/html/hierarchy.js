var hierarchy =
[
    [ "Controller", "class_controller.html", null ],
    [ "FilterBilateral", "class_filter_bilateral.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QThread", null, [
      [ "ControllerThread", "class_controller_thread.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "WidgetImage", "class_widget_image.html", null ]
    ] ]
];