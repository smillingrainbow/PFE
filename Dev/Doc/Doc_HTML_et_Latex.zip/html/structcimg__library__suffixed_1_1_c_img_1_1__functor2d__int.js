var structcimg__library__suffixed_1_1_c_img_1_1__functor2d__int =
[
    [ "_functor2d_int", "structcimg__library__suffixed_1_1_c_img_1_1__functor2d__int.html#a074e1ac30146d816693b3f59bcb9f14a", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor2d__int.html#a0ac2fe8f345280cec6d4dbb4dab882cb", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor2d__int.html#a952a4a6b8aea9d7fe271512db336a0bf", null ]
];