var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01signed_01char_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01signed_01char_01_4.html#a1092e516767772f3376345fddaa5eed4", null ]
];