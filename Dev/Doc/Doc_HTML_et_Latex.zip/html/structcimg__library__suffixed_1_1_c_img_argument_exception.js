var structcimg__library__suffixed_1_1_c_img_argument_exception =
[
    [ "CImgArgumentException", "structcimg__library__suffixed_1_1_c_img_argument_exception.html#aa9078e8f95f0a437aac753b505a79255", null ]
];