var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "mainWidjet", "class_main_window.html#a94fce9f5b7a2dd7564bb91b3e624f7c0", null ]
];