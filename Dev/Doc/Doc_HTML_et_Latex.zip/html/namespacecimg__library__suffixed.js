var namespacecimg__library__suffixed =
[
    [ "cimg", "namespacecimg__library__suffixed_1_1cimg.html", "namespacecimg__library__suffixed_1_1cimg" ],
    [ "CImg", "structcimg__library__suffixed_1_1_c_img.html", "structcimg__library__suffixed_1_1_c_img" ],
    [ "CImgArgumentException", "structcimg__library__suffixed_1_1_c_img_argument_exception.html", "structcimg__library__suffixed_1_1_c_img_argument_exception" ],
    [ "CImgDisplay", "structcimg__library__suffixed_1_1_c_img_display.html", "structcimg__library__suffixed_1_1_c_img_display" ],
    [ "CImgDisplayException", "structcimg__library__suffixed_1_1_c_img_display_exception.html", "structcimg__library__suffixed_1_1_c_img_display_exception" ],
    [ "CImgException", "structcimg__library__suffixed_1_1_c_img_exception.html", "structcimg__library__suffixed_1_1_c_img_exception" ],
    [ "CImgInstanceException", "structcimg__library__suffixed_1_1_c_img_instance_exception.html", "structcimg__library__suffixed_1_1_c_img_instance_exception" ],
    [ "CImgIOException", "structcimg__library__suffixed_1_1_c_img_i_o_exception.html", "structcimg__library__suffixed_1_1_c_img_i_o_exception" ],
    [ "CImgList", "structcimg__library__suffixed_1_1_c_img_list.html", "structcimg__library__suffixed_1_1_c_img_list" ],
    [ "CImgWarningException", "structcimg__library__suffixed_1_1_c_img_warning_exception.html", "structcimg__library__suffixed_1_1_c_img_warning_exception" ]
];