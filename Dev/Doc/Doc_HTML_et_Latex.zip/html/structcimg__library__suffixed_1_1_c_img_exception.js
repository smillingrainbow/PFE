var structcimg__library__suffixed_1_1_c_img_exception =
[
    [ "CImgException", "structcimg__library__suffixed_1_1_c_img_exception.html#a1931cba265f653b52806c4361f3cecfc", null ],
    [ "CImgException", "structcimg__library__suffixed_1_1_c_img_exception.html#aeb349b6446eb9bd5ca8a6c0106e69c34", null ],
    [ "what", "structcimg__library__suffixed_1_1_c_img_exception.html#a993f11b05af5a1bffc5f08a4c4ccdf63", null ],
    [ "_message", "structcimg__library__suffixed_1_1_c_img_exception.html#a1547ff5f86f5e7aa075304077eb31f00", null ]
];