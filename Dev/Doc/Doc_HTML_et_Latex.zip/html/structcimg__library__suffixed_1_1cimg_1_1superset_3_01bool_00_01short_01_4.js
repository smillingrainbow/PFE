var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01short_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01short_01_4.html#ad10e5178f0b07ea71386f97bb41043bf", null ]
];