var annotated =
[
    [ "Controller", "class_controller.html", "class_controller" ],
    [ "ControllerThread", "class_controller_thread.html", "class_controller_thread" ],
    [ "FilterBilateral", "class_filter_bilateral.html", "class_filter_bilateral" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "WidgetImage", "class_widget_image.html", "class_widget_image" ]
];