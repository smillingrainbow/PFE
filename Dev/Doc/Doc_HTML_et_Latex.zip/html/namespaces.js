var namespaces =
[
    [ "cimg_library_suffixed", "namespacecimg__library__suffixed.html", "namespacecimg__library__suffixed" ]
];