var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01float_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01float_01_4.html#aa08032fc0bd77f43b6a14c23c770b82f", null ]
];