var structcimg__library__suffixed_1_1_c_img_1_1__functor3d__float =
[
    [ "_functor3d_float", "structcimg__library__suffixed_1_1_c_img_1_1__functor3d__float.html#ae04ad42104133ff47ef65a564e49e73c", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor3d__float.html#a306a987f6e64f730aa66756bb1897c74", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor3d__float.html#a531d8e028bb752be2629ff14f9fc6a37", null ]
];