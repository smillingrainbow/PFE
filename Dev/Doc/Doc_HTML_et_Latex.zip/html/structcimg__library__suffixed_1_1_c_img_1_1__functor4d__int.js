var structcimg__library__suffixed_1_1_c_img_1_1__functor4d__int =
[
    [ "_functor4d_int", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__int.html#a497876b7332984108b6ae60b9bd3a1ce", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__int.html#ac41ab34b9522d25f4202f536d4867ee2", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__int.html#a6c9cfad39fcfbb4617efdd5e33509d46", null ]
];