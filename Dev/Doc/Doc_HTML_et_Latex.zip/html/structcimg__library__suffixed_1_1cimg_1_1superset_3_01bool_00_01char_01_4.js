var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01char_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01char_01_4.html#acdae5243dfde2cfcae0537d0cea059cd", null ]
];