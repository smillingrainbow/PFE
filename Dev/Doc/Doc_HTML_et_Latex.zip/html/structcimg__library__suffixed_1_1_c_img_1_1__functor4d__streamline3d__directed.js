var structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__directed =
[
    [ "_functor4d_streamline3d_directed", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__directed.html#ae6cf32c7a4e1b38bf10befe1c8256759", null ],
    [ "operator()", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__directed.html#a62eb852f97e18e7c7cf52d50171825a3", null ],
    [ "ref", "structcimg__library__suffixed_1_1_c_img_1_1__functor4d__streamline3d__directed.html#a1388dcdcefe2dbf80bacf81e4fb29673", null ]
];