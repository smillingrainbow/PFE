var structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01unsigned_01int_01_4 =
[
    [ "type", "structcimg__library__suffixed_1_1cimg_1_1superset_3_01bool_00_01unsigned_01int_01_4.html#a1e9c2d39872148d655400d97fa9be87a", null ]
];